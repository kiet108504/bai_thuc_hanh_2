#include<stdio.h>
struct sv{
	char hoten[50],ma[20];
	float d1,d2,d3;
};
int main(){
	int i,n;
	struct sv SV[100];
	printf("Nhap so sv ");
	scanf("%d",&n);

	for(i = 0;i<n;i++){
	printf("\nSinh vien %d\n",i+1);
	printf("Ho ten ");
	scanf("%s",SV[i].hoten);
	printf("\nMa sv ");
	scanf("%s",SV[i].ma);
	printf("\ndiem 1: ");
	scanf("%f",&SV[i].d1);
	printf("\ndiem 2: ");
	scanf("%f",&SV[i].d2);
	printf("\ndiem 3: ");
	scanf("%f",&SV[i].d3);	
	}
	printf("\ndanh sach sinh vien\n");
	for(i = 0;i<n;i++){
		printf("\nHo ten: %s",SV[i].hoten);
		printf("\nMa sinh vien: %s",SV[i].ma);
		printf("\ndiem 1: %.2f",SV[i].d1);
		printf("\ndiem 2: %.2f",SV[i].d2);
		printf("\ndiem 3: %.2f",SV[i].d3);
	}
	
	
	return 0;
}
