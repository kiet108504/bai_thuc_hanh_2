#include<stdio.h>
int main(){
	int m,i,n,j;
	float a[100][100];
	float *p;
	p = &a[0][0];
	printf("Nhap so dong ");
	scanf("%d",&m);
	printf("Nhap so cot ");
	scanf("%d",&n);
	printf("Nhap so cac phan tu mang \n");

	for(i = 0;i<m;i++){
		for(j=0;j<n;j++){
		printf("Nhap a[%d][%d] ",i,j);
		scanf("%f",(p+i*n+j));
	}}
	
	printf("\nMang ban vua nhap la:\n");
	for(i = 0;i<m;i++){
		for(j=0;j<n;j++){
		printf("%.2f\t ",*(p+i*n+j));
	
	}printf("\n");}
	
	
	return 0;
}
