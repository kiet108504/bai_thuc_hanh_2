#include<stdio.h>
#include<stdlib.h>
typedef struct{
	char hoten[50],ma[10];
	float d1,d2,d3;
}SV;
typedef struct lksv{
	SV infor;
	struct lksv *link;
}Node;

